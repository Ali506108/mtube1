from django.shortcuts import render

from .models import video
def index(request):
    videos = video.objects.all()
    return render(request, 'videos/index.html',context={'videos':videos})